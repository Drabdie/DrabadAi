# MagicTuner Pro · Pixel 8 🎮⚡ (v2.1.0-pro)

Объединённая версия тюнера для Pixel: полный каталог твиков + термо-guard + авто-буст игр.
Всё работает **без root** через [Shizuku](https://shizuku.rikka.app/).
ROOT-твики (governor, ZRAM и т.п.) активируются только если на устройстве уже есть Magisk/KernelSU.

**Обновления v2.1.0:**
- compileSdk / targetSdk → 35
- Свежие зависимости (Compose BOM 2024.12, Core 1.15 и т.д.)
- Добавлен GitHub Actions — собирай APK с телефона
- Улучшена структура debug/release
- Версия 2.1.0-pro

## Как собрать APK через GitHub Actions (самый удобный способ с Pixel)

1. Создай новый репозиторий на GitHub.
2. Залей **всё содержимое** этой папки так, чтобы `settings.gradle.kts` и `build.gradle.kts` лежали в корне репозитория.
3. Перейди в **Actions** → выбери workflow **Build debug APK** → **Run workflow**.
4. После успешной сборки скачай артефакт `magictuner-pro-debug-apk`.

## Сборка на телефоне (AndroidIDE / AIDE)

1. Распакуй архив.
2. Открой папку проекта в AndroidIDE.
3. Дождись Gradle Sync (может попросить скачать SDK components — согласись).
4. Build → Assemble Debug.
5. APK появится в `app/build/outputs/apk/debug/`.

## Требования
- Google Pixel 8 / 8 Pro (или близкие), Android 14+
- Установленный Shizuku (Play Store или GitHub)
- Для ROOT-твиков — Magisk / KernelSU (опционально)

## Важно
- Твики, держащие частоты на максимуме, греют телефон и жрут батарею.
- Термо-guard автоматически снимает опасные твики при сильном нагреве.
- Всегда можно откатить любой твик или все сразу.
- Приложение не даёт root и не ищет способы его получить.

Удачной сборки и безопасных твиков!
