# Shizuku использует Binder через AIDL — не обфусцируем его пакеты.
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }
-keepclassmembers class * implements android.os.Parcelable { *; }
