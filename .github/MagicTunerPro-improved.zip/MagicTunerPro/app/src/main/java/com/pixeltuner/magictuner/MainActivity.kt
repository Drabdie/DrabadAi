package com.pixeltuner.magictuner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pixeltuner.magictuner.core.DisplayInfo
import com.pixeltuner.magictuner.core.TunerViewModel
import com.pixeltuner.magictuner.shell.ExecMode
import com.pixeltuner.magictuner.tweak.TweakCategory
import com.pixeltuner.magictuner.tweak.TweakTier
import com.pixeltuner.magictuner.ui.theme.MagicTunerTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    private val vm: TunerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MagicTunerTheme { RootScreen(vm, this) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RootScreen(vm: TunerViewModel, activity: MainActivity) {
    val ui by vm.ui.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Твики", "Профили", "Лог", "Статус")

    // Живые показания официальных API (без Shizuku): частота экрана + аппаратный термостатус.
    LaunchedEffect(Unit) {
        while (true) {
            vm.updateRefreshRate(DisplayInfo.currentRefreshRateHz(activity))
            vm.refreshHardwareStatus()
            vm.refreshUsageAccess()
            delay(3000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MagicTuner · Pixel 8", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.primary
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text("•") },
                        label = { Text(t) }
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            StatusBanner(ui, onRefresh = vm::refreshStatus)
            when (tab) {
                0 -> TweaksTab(vm, ui)
                1 -> ProfilesTab(vm, ui)
                2 -> LogTab(ui)
                else -> AboutTab(ui)
            }
        }
    }
}

@Composable
private fun StatusBanner(ui: com.pixeltuner.magictuner.core.TunerUiState, onRefresh: () -> Unit) {
    val ok = ui.shizukuAlive && ui.shizukuGranted
    Surface(
        color = if (ok) Color(0xFF10301A) else Color(0xFF301018),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(ui.device, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(
                    if (ok) "Shizuku: активен, разрешение выдано"
                    else "Shizuku: не активен — запусти Shizuku и дай доступ",
                    fontSize = 12.sp
                )
                Text(
                    "Экран: ${ui.refreshRateHz.toInt()}Гц · Термо: ${ui.hwThermalStatus}",
                    fontSize = 11.sp,
                    color = if (ui.hwThermalHot) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.onSurface.copy(0.7f)
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                if (!ui.isPixel8) {
                    Text("⚠ не Pixel 8", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                }
                TextButton(onClick = onRefresh) { Text("Обновить") }
            }
        }
    }
}

@Composable
private fun TweaksTab(vm: TunerViewModel, ui: com.pixeltuner.magictuner.core.TunerUiState) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { vm.gameBoost() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("⚡", fontSize = 16.sp)
                    Spacer(Modifier.width(6.dp))
                    Text("GAME BOOST", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(onClick = { vm.applyAllSafe() }, modifier = Modifier.weight(1f)) {
                    Text("Включить всё")
                }
            }
        }
        item {
            OutlinedButton(onClick = { vm.revertAll() }, modifier = Modifier.fillMaxWidth()) {
                Text("Откатить всё")
            }
        }
        item { TargetPackagePicker(vm, ui) }
        item { ModePicker(vm, ui) }
        item { AutoBoostCard(vm, ui) }

        vm.catalog().forEach { (cat, list) ->
            item {
                Text(
                    catTitle(cat),
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
            items(list, key = { it.id }) { t ->
                TweakCard(t, ui.enabled.contains(t.id), ui.mode,
                    onApply = { vm.applyTweak(t) }, onRevert = { vm.revertTweak(t) })
            }
        }
    }
}

@Composable
private fun ModePicker(vm: TunerViewModel, ui: com.pixeltuner.magictuner.core.TunerUiState) {
    Column {
        Text("Режим выполнения", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ExecMode.values().forEach { m ->
                FilterChip(
                    selected = ui.mode == m,
                    onClick = { vm.setMode(m) },
                    label = { Text(m.name) }
                )
            }
        }
    }
}

@Composable
private fun AutoBoostCard(vm: TunerViewModel, ui: com.pixeltuner.magictuner.core.TunerUiState) {
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Авто-буст по запуску игры", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(
                        "Сам включает набор Game Boost, когда запускается «${ui.targetPackage}», " +
                        "и откатывает при выходе",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(0.7f)
                    )
                }
                Switch(
                    checked = ui.autoBoostEnabled,
                    onCheckedChange = { checked ->
                        if (checked && !ui.usageAccessGranted) {
                            vm.openUsageAccessSettings()
                        } else {
                            vm.setAutoBoost(checked)
                        }
                    }
                )
            }
            if (!ui.usageAccessGranted) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "⚠ Нужен доступ к статистике использования — обычная настройка Android, " +
                    "без ADB и без root.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.error
                )
                TextButton(onClick = { vm.openUsageAccessSettings() }) {
                    Text("Открыть настройку доступа")
                }
            }
        }
    }
}

@Composable
private fun TargetPackagePicker(vm: TunerViewModel, ui: com.pixeltuner.magictuner.core.TunerUiState) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text("Игра-цель", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(ui.targetPackage)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            if (ui.gamePackages.isEmpty()) {
                DropdownMenuItem(text = { Text("Игры не найдены — введи пакет вручную") }, onClick = {})
            }
            ui.gamePackages.forEach { (pkg, label) ->
                DropdownMenuItem(
                    text = { Text("$label\n$pkg", fontSize = 13.sp) },
                    onClick = { vm.setPackage(pkg); expanded = false }
                )
            }
        }
    }
}

@Composable
private fun TweakCard(
    t: com.pixeltuner.magictuner.tweak.Tweak,
    on: Boolean,
    mode: ExecMode,
    onApply: () -> Unit,
    onRevert: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (on) Color(0xFF10271A) else MaterialTheme.colorScheme.surface
        )
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(t.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                AssistChip(
                    onClick = {},
                    label = {
                        Text(
                            if (t.tier == TweakTier.SHIZUKU) "NO-ROOT" else "ROOT",
                            fontSize = 10.sp,
                            color = if (t.tier == TweakTier.SHIZUKU) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.error
                        )
                    }
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(t.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.75f))
            t.warning?.let {
                Spacer(Modifier.height(6.dp))
                Text("⚠ $it", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
            }
            if (t.experimental) {
                Text("экспериментально", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onApply,
                    enabled = on.not() && (mode != ExecMode.SHIZUKU || t.tier == TweakTier.SHIZUKU),
                    modifier = Modifier.weight(1f)
                ) { Text("Применить") }
                OutlinedButton(onClick = onRevert, enabled = on, modifier = Modifier.weight(1f)) {
                    Text("Откатить")
                }
            }
        }
    }
}

@Composable
private fun ProfilesTab(vm: TunerViewModel, ui: com.pixeltuner.magictuner.core.TunerUiState) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Профили одним тапом", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        ProfileButton("🎮 Игровой максимум",
            "Fixed perf + снятие троттлинга + Game Mode + 120 Гц") { vm.gameBoost() }
        ProfileButton("🔋 Экономия",
            "Откат всех твиков, вернуть штатные частоты") { vm.revertAll() }
        ProfileButton("🌡 Баланс",
            "Мягкий троттлинг (override=1) + Game Mode performance") {
            vm.applyAllSafe()
        }
        Text("Активно твиков: ${ui.enabled.size}", fontSize = 13.sp)
    }
}

@Composable
private fun ProfileButton(title: String, sub: String, onClick: () -> Unit) {
    Card(shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.7f))
            Spacer(Modifier.height(8.dp))
            Button(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text("Запустить") }
        }
    }
}

@Composable
private fun LogTab(ui: com.pixeltuner.magictuner.core.TunerUiState) {
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), reverseLayout = true) {
        items(ui.log.reversed()) { line ->
            Text(line, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(0.85f))
        }
    }
}

@Composable
private fun AboutTab(ui: com.pixeltuner.magictuner.core.TunerUiState) {
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("О приложении", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            "MagicTuner Pro оптимизирован под Google Pixel 8 / 8 Pro (Tensor G3).\n" +
            "Все NO-ROOT твики идут через Shizuku (shell uid=2000) — без разблокировки загрузчика.\n\n" +
            "Добавлено при объединении возможностей:\n" +
            "• независимый термо-guard на официальном API — снимает опасные твики при реальном перегреве, " +
            "даже если Shizuku попросил систему игнорировать троттлинг;\n" +
            "• живые показания частоты экрана и температуры из системных датчиков (не из shell-команд);\n" +
            "• авто-буст: сам включает Game Boost при запуске выбранной игры и откатывает при выходе;\n" +
            "• GPU governor (Mali-G715) в дополнение к CPU governor — root-уровень.",
            fontSize = 13.sp
        )
        Text("Девайс: ${ui.device}", fontSize = 13.sp)
        Text("Shizuku: ${if (ui.shizukuGranted) "OK" else "нет доступа"}", fontSize = 13.sp)
        Text("Найдено игр: ${ui.gamePackages.size}", fontSize = 13.sp)
        Text("Режим: ${ui.mode.name}", fontSize = 13.sp)
        Text("Частота экрана (факт.): ${ui.refreshRateHz.toInt()}Гц", fontSize = 13.sp)
        Text("Термостатус (факт.): ${ui.hwThermalStatus}", fontSize = 13.sp)
        Text("Авто-буст: ${if (ui.autoBoostEnabled) "включён" else "выключен"}", fontSize = 13.sp)
    }
}

private fun catTitle(c: TweakCategory): String = when (c) {
    TweakCategory.CORE -> "⚙ Производительность ядра"
    TweakCategory.THERMAL -> "🌡 Термальный контроль"
    TweakCategory.GAME -> "🎮 Игровой режим"
    TweakCategory.DISPLAY -> "🖥 Дисплей и отклик"
    TweakCategory.RENDER -> "🎨 Рендеринг GPU"
    TweakCategory.MEMORY -> "💾 Память"
    TweakCategory.KERNEL -> "🧠 Ядро и частоты (root)"
}
