package com.pixeltuner.magictuner

import android.app.Application

/**
 * Точка входа приложения. Пока ничего тяжёлого — весь движок живёт в синглтонах
 * (ShellEngine / TweakCatalog) и лениво инициализируется при первом обращении.
 */
class TunerApp : Application()
