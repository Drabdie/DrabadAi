package com.pixeltuner.magictuner.core

import android.app.Activity

/**
 * Официальный, бесплатный по разрешениям способ узнать реальную частоту обновления
 * экрана — без Shizuku и без root. Используется для проверки, действительно ли
 * твик "Зафиксировать 120 Гц" сработал, а не просто отправил команду в никуда.
 */
object DisplayInfo {
    fun currentRefreshRateHz(activity: Activity): Float =
        activity.display?.refreshRate ?: 60f

    fun maxSupportedRefreshRateHz(activity: Activity): Float =
        activity.display?.supportedModes?.maxOfOrNull { it.refreshRate } ?: 60f
}
