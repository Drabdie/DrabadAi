package com.pixeltuner.magictuner.core

import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.pixeltuner.magictuner.shell.ExecMode
import com.pixeltuner.magictuner.shell.ShellEngine

/**
 * Независимая аппаратная защита от перегрева — работает поверх твиков Shizuku.
 *
 * Твики вроде "снять троттлинг" (thermalservice override-status 0) намеренно просят
 * систему игнорировать её собственную тепловую защиту. Это даёт кадры, но при плохом
 * охлаждении может держать чип горячим дольше, чем нужно. ThermalGuard слушает
 * официальный термальный API Android (PowerManager, доступен без разрешений с
 * Android 10+) НАПРЯМУЮ от датчиков, независимо от override-команд, и как только
 * статус доходит до SEVERE — принудительно снимает override и возвращает управление
 * системе, что бы ни было включено в UI.
 */
class ThermalGuard(private val context: Context, private val controller: TweakController) {

    private var lastStatus: Int = PowerManager.THERMAL_STATUS_NONE
    private var guardTripped = false
    var onTrip: ((Int) -> Unit)? = null
    /** Вызывается при каждом изменении статуса — для живого отображения в UI. */
    var onStatusChanged: ((Int) -> Unit)? = null

    fun currentStatus(): Int {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return PowerManager.THERMAL_STATUS_NONE
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.currentThermalStatus
    }

    fun statusLabel(status: Int = currentStatus()): String = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> "Норма"
        PowerManager.THERMAL_STATUS_LIGHT -> "Лёгкий нагрев"
        PowerManager.THERMAL_STATUS_MODERATE -> "Умеренный нагрев"
        PowerManager.THERMAL_STATUS_SEVERE -> "Сильный — защита активируется"
        PowerManager.THERMAL_STATUS_CRITICAL -> "Критично"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "Аварийно"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "Скоро выключение"
        else -> "Неизвестно"
    }

    /** Начать слушать термальные события. Безопасно вызывать многократно. */
    fun start() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.addThermalStatusListener { status ->
            lastStatus = status
            onStatusChanged?.invoke(status)
            if (status >= PowerManager.THERMAL_STATUS_SEVERE && !guardTripped) {
                guardTripped = true
                forceCooldown()
                onTrip?.invoke(status)
            } else if (status < PowerManager.THERMAL_STATUS_MODERATE) {
                guardTripped = false // разрешаем снова использовать агрессивные твики
            }
        }
    }

    /** Снимает самые "горячие" твики немедленно, независимо от режима выполнения. */
    private fun forceCooldown() {
        ShellEngine.run("cmd thermalservice reset", ExecMode.SHIZUKU)
        ShellEngine.run("cmd power set-fixed-performance-mode-enabled false", ExecMode.SHIZUKU)
    }

    /** true — сейчас агрессивные твики блокировать не стоит показывать пользователю как риск. */
    fun isHot(): Boolean = lastStatus >= PowerManager.THERMAL_STATUS_MODERATE
}
