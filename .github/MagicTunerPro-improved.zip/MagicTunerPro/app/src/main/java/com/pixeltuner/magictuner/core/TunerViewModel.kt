package com.pixeltuner.magictuner.core

import android.app.AppOpsManager
import android.app.Application
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pixeltuner.magictuner.service.ForegroundGameWatcher
import com.pixeltuner.magictuner.shell.ExecMode
import com.pixeltuner.magictuner.shell.ShizukuManager
import com.pixeltuner.magictuner.tweak.Tweak
import com.pixeltuner.magictuner.tweak.TweakCatalog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

/** Состояние UI. */
data class TunerUiState(
    val device: String = "",
    val isPixel8: Boolean = false,
    val shizukuAlive: Boolean = false,
    val shizukuGranted: Boolean = false,
    val mode: ExecMode = ExecMode.SHIZUKU,
    val targetPackage: String = TweakController.DEFAULT_PACKAGE,
    val enabled: Set<String> = emptySet(),
    val log: List<String> = emptyList(),
    val gamePackages: List<Pair<String, String>> = emptyList(),
    // --- добавлено при объединении возможностей ---
    val refreshRateHz: Float = 60f,
    val hwThermalStatus: String = "Норма",
    val hwThermalHot: Boolean = false,
    val autoBoostEnabled: Boolean = false,
    val usageAccessGranted: Boolean = false
)

class TunerViewModel(app: Application) : AndroidViewModel(app) {

    private val controller = TweakController(app)
    private val thermalGuard = ThermalGuard(app, controller)
    private val prefs = app.getSharedPreferences("magic_tuner", Application.MODE_PRIVATE)

    private val _ui = MutableStateFlow(
        TunerUiState(
            device = ShizukuManager.deviceLabel(),
            isPixel8 = ShizukuManager.isPixel8Family(),
            mode = controller.mode,
            targetPackage = controller.targetPackage,
            autoBoostEnabled = prefs.getBoolean("auto_boost", false)
        )
    )
    val ui: StateFlow<TunerUiState> = _ui.asStateFlow()

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, grant ->
        refreshShizuku()
        appendLog(if (grant == PackageManager.PERMISSION_GRANTED) "Shizuku: разрешение выдано" else "Shizuku: отказано")
    }

    init {
        Shizuku.addBinderReceivedListenerSticky { refreshShizuku() }
        Shizuku.addBinderDeadListener { refreshShizuku() }
        Shizuku.addRequestPermissionResultListener(permListener)
        refreshShizuku()
        loadGames()

        // Независимый аппаратный термо-guard: слушает реальные датчики, а не то,
        // что мы сами попросили у системы, и снимает опасные твики при перегреве.
        thermalGuard.onTrip = { appendLog("🌡 Термо-защита: обнаружен сильный нагрев — агрессивные твики сброшены") }
        thermalGuard.onStatusChanged = { status ->
            _ui.value = _ui.value.copy(
                hwThermalStatus = thermalGuard.statusLabel(status),
                hwThermalHot = thermalGuard.isHot()
            )
        }
        thermalGuard.start()
        refreshHardwareStatus()

        refreshUsageAccess()
    }

    override fun onCleared() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onCleared()
    }

    /** Обновляет показания официальных API (термо + частота), независимо от Shizuku. */
    fun refreshHardwareStatus() {
        val status = thermalGuard.currentStatus()
        _ui.value = _ui.value.copy(
            hwThermalStatus = thermalGuard.statusLabel(status),
            hwThermalHot = thermalGuard.isHot()
        )
    }

    fun updateRefreshRate(hz: Float) {
        _ui.value = _ui.value.copy(refreshRateHz = hz)
    }

    fun refreshUsageAccess() {
        val app = getApplication<Application>()
        val appOps = app.getSystemService(Application.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), app.packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), app.packageName)
        }
        _ui.value = _ui.value.copy(usageAccessGranted = mode == AppOpsManager.MODE_ALLOWED)
    }

    fun openUsageAccessSettings() {
        val app = getApplication<Application>()
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        app.startActivity(intent)
    }

    /** Включает/выключает автоматический буст при запуске выбранной игры-цели. */
    fun setAutoBoost(enabled: Boolean) {
        val app = getApplication<Application>()
        prefs.edit().putBoolean("auto_boost", enabled).apply()
        _ui.value = _ui.value.copy(autoBoostEnabled = enabled)
        val intent = Intent(app, ForegroundGameWatcher::class.java)
        if (enabled) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) app.startForegroundService(intent)
            else app.startService(intent)
            appendLog("Авто-буст включён для ${controller.targetPackage}")
        } else {
            app.stopService(intent)
            appendLog("Авто-буст выключен")
        }
    }

    fun refreshStatus() {
        refreshShizuku()
        appendLog("Статус обновлён")
    }

    fun clearLog() {
        _ui.value = _ui.value.copy(log = emptyList())
    }

    fun refreshShizuku() {
        _ui.value = _ui.value.copy(
            shizukuAlive = ShizukuManager.isBinderAlive(),
            shizukuGranted = ShizukuManager.hasPermission()
        )
    }

    fun requestShizuku() = ShizukuManager.requestPermission(permListener)

    fun setMode(m: ExecMode) {
        controller.setMode(m)
        _ui.value = _ui.value.copy(mode = m)
    }

    fun setPackage(pkg: String) {
        controller.targetPackage = pkg
        _ui.value = _ui.value.copy(targetPackage = pkg)
    }

    fun applyTweak(t: Tweak) = viewModelScope.launch {
        val res = withContext(Dispatchers.IO) { controller.apply(t) }
        appendLog("✓ ${t.title}: ${controller.lastResultText(res)}")
        syncEnabled()
    }

    fun revertTweak(t: Tweak) = viewModelScope.launch {
        val res = withContext(Dispatchers.IO) { controller.revert(t) }
        appendLog("↩ ${t.title}: ${controller.lastResultText(res)}")
        syncEnabled()
    }

    fun applyAllSafe() = viewModelScope.launch {
        appendLog("── Активация всех безопасных твиков ──")
        val results = withContext(Dispatchers.IO) { controller.applyAllSafe() }
        results.forEach { (t, r) -> appendLog("• ${t.title}: exit ${r.exitCode}") }
        syncEnabled()
    }

    fun revertAll() = viewModelScope.launch {
        appendLog("── Откат всех активных твиков ──")
        val results = withContext(Dispatchers.IO) { controller.revertAll() }
        results.forEach { (t, r) -> appendLog("• ${t.title}: exit ${r.exitCode}") }
        syncEnabled()
    }

    fun gameBoost() = viewModelScope.launch {
        appendLog("── GAME BOOST: один тап ──")
        val quickIds = setOf("fixed_perf_mode", "thermal_override", "game_mode_perf", "force_120", "game_dashboard")
        val quick = TweakCatalog.all.filter { it.id in quickIds && it.tier == com.pixeltuner.magictuner.tweak.TweakTier.SHIZUKU }
        quick.forEach { t ->
            val r = withContext(Dispatchers.IO) { controller.apply(t) }
            appendLog("⚡ ${t.title}: exit ${r.exitCode}")
        }
        syncEnabled()
    }

    private fun syncEnabled() {
        _ui.value = _ui.value.copy(
            enabled = TweakCatalog.all.filter { controller.isEnabled(it.id) }.map { it.id }.toSet()
        )
    }

    private fun appendLog(line: String) {
        _ui.value = _ui.value.copy(log = (_ui.value.log + line).takeLast(200))
    }

    private fun loadGames() {
        viewModelScope.launch {
            val pm = getApplication<Application>().packageManager
            val games = withContext(Dispatchers.IO) {
                if (android.os.Build.VERSION.SDK_INT >= 33) {
                    pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getInstalledApplications(0)
                }
                    .mapNotNull { ai ->
                        if (ai.category == ApplicationInfo.CATEGORY_GAME) {
                            ai.packageName to pm.getApplicationLabel(ai).toString()
                        } else null
                    }.sortedBy { it.second }
            }
            _ui.value = _ui.value.copy(gamePackages = games)
        }
    }

    fun catalog() = TweakCatalog.byCategory()
}
