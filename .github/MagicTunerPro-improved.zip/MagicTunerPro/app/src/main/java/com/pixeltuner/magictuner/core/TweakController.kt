package com.pixeltuner.magictuner.core

import android.content.Context
import android.content.SharedPreferences
import com.pixeltuner.magictuner.shell.ExecMode
import com.pixeltuner.magictuner.shell.ShellEngine
import com.pixeltuner.magictuner.shell.ShellResult
import com.pixeltuner.magictuner.tweak.Tweak
import com.pixeltuner.magictuner.tweak.TweakCatalog

/**
 * Движок применения твиков.
 * • Подставляет выбранный игровой пакет в команды.
 * • Перед первым применением сохраняет оригинал системного ключа (бэкап).
 * • Умеет «Активировать всё», откатывать по одному и полностью сбрасывать.
 */
class TweakController(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("magic_tuner", Context.MODE_PRIVATE)

    /** id твика → включён? */
    private val enabledMap = mutableMapOf<String, Boolean>()
    /** id твика → оригинальное значение ключа (для restore) */
    private val backupMap = mutableMapOf<String, String>()

    init {
        loadState()
    }

    val mode: ExecMode
        get() = ExecMode.valueOf(prefs.getString("mode", ExecMode.SHIZUKU.name)!!)

    fun setMode(m: ExecMode) = prefs.edit().putString("mode", m.name).apply()

    var targetPackage: String
        get() = prefs.getString("pkg", DEFAULT_PACKAGE) ?: DEFAULT_PACKAGE
        set(value) = prefs.edit().putString("pkg", value).apply()

    fun isEnabled(id: String): Boolean = enabledMap[id] == true

    private fun loadState() {
        prefs.getStringSet("enabled", emptySet()).orEmpty().forEach { enabledMap[it] = true }
        prefs.getStringSet("backups", emptySet()).orEmpty().forEach { entry ->
            val parts = entry.split("\u001f", limit = 2)
            if (parts.size == 2) backupMap[parts[0]] = parts[1]
        }
    }

    private fun persistState() {
        val enabled = enabledMap.filterValues { it }.keys
        val backups = backupMap.map { "${it.key}\u001f${it.value}" }.toSet()
        prefs.edit().putStringSet("enabled", enabled).putStringSet("backups", backups).apply()
    }

    fun enabledCount(): Int = enabledMap.count { it.value }

    /** Команда с подстановкой пакета. */
    private fun resolve(t: Tweak, raw: String): String =
        if (t.needsPackage) raw.replace("{pkg}", targetPackage) else raw

    /** Бэкап оригинала системного ключа перед изменением. */
    private fun backup(t: Tweak) {
        val key = t.backupKey ?: return
        if (backupMap.containsKey(t.id)) return
        val parts = key.split(":", limit = 2)
        if (parts.size != 2) return
        val res = ShellEngine.run("settings get ${parts[0]} ${parts[1]}", mode)
        backupMap[t.id] = res.stdout.ifBlank { "null" }
        persistState()
    }

    fun apply(t: Tweak): ShellResult {
        if (t.tier != com.pixeltuner.magictuner.tweak.TweakTier.SHIZUKU && mode == ExecMode.SHIZUKU) {
            // Отказ явно, а не «молча не сработало».
            return ShellResult(-1, "", "Этот твик требует root, а выбран режим Shizuku.")
        }
        backup(t)
        val res = ShellEngine.run(resolve(t, t.apply), mode)
        if (res.ok || mode == ExecMode.DRY) enabledMap[t.id] = true
        persistState()
        return res
    }

    fun revert(t: Tweak): ShellResult {
        val res = ShellEngine.run(resolve(t, t.revert), mode)
        enabledMap[t.id] = false
        persistState()
        return res
    }

    /** Включить всё «безопасное» — все твики уровня Shizuku. */
    fun applyAllSafe(): List<Pair<Tweak, ShellResult>> =
        TweakCatalog.all
            .filter { it.tier == com.pixeltuner.magictuner.tweak.TweakTier.SHIZUKU }
            .map { it to apply(it) }

    fun revertAll(): List<Pair<Tweak, ShellResult>> =
        TweakCatalog.all.filter { isEnabled(it.id) }.map { it to revert(it) }

    fun lastResultText(res: ShellResult): String =
        "[exit ${res.exitCode}] ${res.output}"

    companion object {
        /** PUBG / BGMI стабильно понимает Game Mode; замени на свою игру. */
        const val DEFAULT_PACKAGE = "com.tencent.ig"
    }
}
