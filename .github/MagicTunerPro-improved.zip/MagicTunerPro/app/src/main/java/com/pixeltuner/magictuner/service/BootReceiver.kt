package com.pixeltuner.magictuner.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.pixeltuner.magictuner.shell.ExecMode
import com.pixeltuner.magictuner.shell.ShellEngine

/**
 * Восстановление твиков после перезагрузки. Большинство settings-ключей и device_config
 * сохраняются, но thermal override и fixed-performance-mode сбрасываются —
 * повторяем их, если пользователь включил «Авто-восстановление».
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("magic_tuner", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("autorestore", false)) return

        ShellEngine.run("cmd power set-fixed-performance-mode-enabled true", ExecMode.SHIZUKU)
        ShellEngine.run("cmd thermalservice override-status 0", ExecMode.SHIZUKU)
        ShellEngine.run("settings put system peak_refresh_rate 120.0", ExecMode.SHIZUKU)
    }
}
