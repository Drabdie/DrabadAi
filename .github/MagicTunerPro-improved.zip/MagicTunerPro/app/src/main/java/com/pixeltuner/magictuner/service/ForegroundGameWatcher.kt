package com.pixeltuner.magictuner.service

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.pixeltuner.magictuner.tweak.TweakCatalog
import com.pixeltuner.magictuner.tweak.TweakTier
import com.pixeltuner.magictuner.core.TweakController
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * Автоматизация "GAME BOOST одним тапом": следит, какое приложение на переднем
 * плане (через официальный UsageStatsManager — требует включённого доступа к
 * статистике использования, выдаётся в Настройках, ADB не нужен), и сам применяет
 * "быстрый" набор твиков, когда запускается выбранная игра, откатывая их, когда
 * игра закрывается. Работает только в режиме Shizuku (без root не трогает ядро).
 */
class ForegroundGameWatcher : Service() {

    private lateinit var controller: TweakController
    private var executor: ScheduledExecutorService? = null
    private var boostActive = false
    private val channelId = "magictuner_watcher_channel"

    private val quickIds = setOf(
        "fixed_perf_mode", "thermal_override", "game_mode_perf", "force_120", "game_dashboard"
    )

    override fun onCreate() {
        super.onCreate()
        controller = TweakController(applicationContext)
        createChannel()
        startForeground(2, buildNotification("Слежу за запуском выбранной игры…"))

        executor = Executors.newSingleThreadScheduledExecutor().also { ex ->
            ex.scheduleWithFixedDelay({ tick() }, 0, 4, TimeUnit.SECONDS)
        }
    }

    private fun tick() {
        val fg = currentForegroundPackage() ?: return
        val target = controller.targetPackage
        val quick = TweakCatalog.all.filter { it.id in quickIds && it.tier == TweakTier.SHIZUKU }

        if (fg == target && !boostActive) {
            boostActive = true
            quick.forEach { controller.apply(it) }
            updateNotification("Буст активен: $target")
        } else if (fg != target && boostActive) {
            boostActive = false
            quick.forEach { controller.revert(it) }
            updateNotification("Слежу за запуском выбранной игры…")
        }
    }

    private fun currentForegroundPackage(): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return null
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 8_000, now)
        var last: String? = null
        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) last = event.packageName
        }
        return last
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "MagicTuner: авто-буст", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, channelId)
            .setContentTitle("MagicTuner · авто-буст")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(2, buildNotification(text))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        executor?.shutdownNow()
        if (boostActive) {
            val quick = TweakCatalog.all.filter { it.id in quickIds && it.tier == TweakTier.SHIZUKU }
            quick.forEach { controller.revert(it) }
        }
    }
}
