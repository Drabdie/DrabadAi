package com.pixeltuner.magictuner.service

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.pixeltuner.magictuner.shell.ExecMode
import com.pixeltuner.magictuner.shell.ShellEngine

/**
 * Плитка быстрых настроек: один тап → Game Boost.
 * Выполняет минимальный набор команд прямо из тайла.
 */
class GameBoostTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        qsTile?.state = Tile.STATE_INACTIVE
        qsTile?.updateTile()
    }

    override fun onClick() {
        super.onClick()
        val tile = qsTile ?: return
        val turningOn = tile.state != Tile.STATE_ACTIVE

        if (turningOn) {
            ShellEngine.run("cmd power set-fixed-performance-mode-enabled true", ExecMode.SHIZUKU)
            ShellEngine.run("cmd thermalservice override-status 0", ExecMode.SHIZUKU)
            ShellEngine.run("settings put system peak_refresh_rate 120.0; settings put system min_refresh_rate 120.0", ExecMode.SHIZUKU)
            tile.state = Tile.STATE_ACTIVE
        } else {
            ShellEngine.run("cmd power set-fixed-performance-mode-enabled false", ExecMode.SHIZUKU)
            ShellEngine.run("cmd thermalservice reset", ExecMode.SHIZUKU)
            ShellEngine.run("settings put system min_refresh_rate 0.0", ExecMode.SHIZUKU)
            tile.state = Tile.STATE_INACTIVE
        }
        tile.label = "Game Boost"
        tile.updateTile()
    }
}
