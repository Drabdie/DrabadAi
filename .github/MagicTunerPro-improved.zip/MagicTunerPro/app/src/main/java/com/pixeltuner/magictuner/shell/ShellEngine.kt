package com.pixeltuner.magictuner.shell

import rikka.shizuku.Shizuku
import java.io.BufferedReader

/**
 * Выполнение shell-команд. Три режима:
 *  - SHIZUKU — от имени shell (uid 2000) через Shizuku, без root;
 *  - ROOT    — через `su -c` (Magisk/KernelSU), нужен для clock/governor/ZRAM;
 *  - DRY     — только показать, что будет выполнено (режим предпросмотра).
 *
 * В Shizuku API метод newProcess() помечен @RestrictTo и в релизной сборке
 * может быть приватным, поэтому вызываем его через рефлексию — это официально
 * документированный способ запуска процесса от имени shell.
 */
enum class ExecMode { SHIZUKU, ROOT, DRY }

object ShellEngine {

    private var newProcessMethod: java.lang.reflect.Method? = null

    private fun resolveNewProcess(): java.lang.reflect.Method? {
        newProcessMethod?.let { return it }
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            newProcessMethod = m
            m
        } catch (t: Throwable) {
            null
        }
    }

    /** Многострочные команды разбиваются по ';' и выполняются последовательно. */
    fun run(cmd: String, mode: ExecMode): ShellResult = when (mode) {
        ExecMode.DRY -> ShellResult(0, "DRY-RUN: $cmd", "")
        ExecMode.SHIZUKU -> runShizuku(cmd)
        ExecMode.ROOT -> runRoot(cmd)
    }

    private fun runShizuku(cmd: String): ShellResult {
        return try {
            val method = resolveNewProcess()
            if (method == null) {
                ShellResult(-1, "", "Shizuku: метод newProcess недоступен в этой версии API.")
            } else {
                val proc = method.invoke(null, arrayOf("sh", "-c", cmd), null, null) as? Process
                if (proc == null) {
                    ShellResult(-1, "", "Shizuku: не удалось запустить процесс.")
                } else {
                    proc.readAndWait()
                }
            }
        } catch (t: Throwable) {
            ShellResult(-1, "", "Shizuku: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    private fun runRoot(cmd: String): ShellResult = try {
        Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).readAndWait()
    } catch (t: Throwable) {
        ShellResult(-1, "", "Root: ${t.message ?: "su не найден"}")
    }

    private fun Process.readAndWait(): ShellResult {
        val out = inputStream.bufferedReader().use(BufferedReader::readText)
        val err = errorStream.bufferedReader().use(BufferedReader::readText)
        val code = waitFor()
        return ShellResult(code, out.trim(), err.trim())
    }
}
