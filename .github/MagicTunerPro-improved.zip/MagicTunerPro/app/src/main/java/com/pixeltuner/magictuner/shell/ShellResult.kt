package com.pixeltuner.magictuner.shell

/** Результат выполнения shell-команды. */
data class ShellResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String
) {
    val ok: Boolean get() = exitCode == 0
    val output: String get() = when {
        stdout.isNotBlank() -> stdout
        stderr.isNotBlank() -> stderr
        else -> "(пусто)"
    }
}
