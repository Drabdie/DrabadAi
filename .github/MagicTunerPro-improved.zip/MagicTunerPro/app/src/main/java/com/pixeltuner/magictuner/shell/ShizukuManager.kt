package com.pixeltuner.magictuner.shell

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import rikka.shizuku.Shizuku

/**
 * Обёртка над Shizuku: проверка доступности, запрос прав и выполнение shell-команд
 * от имени пользователя shell (uid 2000). Именно это даёт доступ к `settings`,
 * `cmd power`, `cmd thermalservice`, `device_config` и `cmd game` БЕЗ root.
 */
object ShizukuManager {

    const val REQ_CODE = 4242

    fun isBinderAlive(): Boolean = try {
        Shizuku.pingBinder()
    } catch (t: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        isBinderAlive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (t: Throwable) {
        false
    }

    /** true, если Shizuku запущен, но наше приложение ещё не получило разрешение. */
    fun needsPermissionRequest(): Boolean = try {
        isBinderAlive() && Shizuku.shouldShowRequestPermissionRationale()
    } catch (t: Throwable) {
        false
    }

    fun requestPermission(listener: Shizuku.OnRequestPermissionResultListener) {
        try {
            Shizuku.addRequestPermissionResultListener(listener)
            Shizuku.requestPermission(REQ_CODE)
        } catch (t: Throwable) {
            // Shizuku не запущен — молча игнорируем, UI покажет статус.
        }
    }

    fun removeListener(listener: Shizuku.OnRequestPermissionResultListener) {
        try { Shizuku.removeRequestPermissionResultListener(listener) } catch (_: Throwable) {}
    }

    /** Проверка «наш ли это девайс» — Pixel 8 / 8 Pro на Tensor G3. */
    fun isPixel8Family(): Boolean {
        val model = "${Build.MANUFACTURER} ${Build.MODEL}".lowercase()
        return model.contains("pixel 8") || model.contains("shiba") || model.contains("husky")
    }

    fun deviceLabel(): String = "${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})"
}
