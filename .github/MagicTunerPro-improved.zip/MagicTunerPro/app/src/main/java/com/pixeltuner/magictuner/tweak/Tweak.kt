package com.pixeltuner.magictuner.tweak

/** Уровень доступа, требуемый для твика — чтобы ничего не «молча не срабатывало». */
enum class TweakTier(val label: String, val hint: String) {
    SHIZUKU("Shizuku / ADB", "Работает без root. Нужен запущенный Shizuku с выданным разрешением."),
    ROOT("Root", "Требуется Magisk / KernelSU. Без root команда не выполнится.")
}

/** Логическая группа для UI. */
enum class TweakCategory(val title: String) {
    CORE("Производительность ядра"),
    THERMAL("Термальный контроль"),
    GAME("Игровой режим"),
    DISPLAY("Дисплей и отклик"),
    RENDER("Рендеринг GPU"),
    MEMORY("Память и фоновые процессы"),
    KERNEL("Ядро и частоты (root)")
}

/**
 * Один твик. apply/revert — shell-команды (можно несколько через ';').
 * backupKey — пара "namespace:key" для бэкапа/восстановления через `settings`.
 * needsPackage — команда подставляет {pkg} выбранной игры.
 */
data class Tweak(
    val id: String,
    val title: String,
    val description: String,
    val category: TweakCategory,
    val tier: TweakTier,
    val apply: String,
    val revert: String,
    val backupKey: String? = null,
    val needsPackage: Boolean = false,
    val warning: String? = null,
    val experimental: Boolean = false
)
