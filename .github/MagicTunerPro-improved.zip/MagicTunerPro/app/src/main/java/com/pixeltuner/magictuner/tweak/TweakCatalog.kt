package com.pixeltuner.magictuner.tweak

/**
 * Каталог твиков, подобранный под Google Pixel 8 / 8 Pro (Tensor G3, Android 14–16).
 *
 * ВАЖНО: команды используют только официальные каналы:
 *   - `cmd power set-fixed-performance-mode-enabled`  (ADPF Fixed Performance Mode)
 *   - `cmd thermalservice override-status` / `reset`  (Thermal API)
 *   - `cmd game mode` / `device_config ... game_overlay` (Game Mode API, Android 12+)
 *   - `settings put system/global ...` (WRITE_SECURE_SETTINGS через Shizuku)
 * Команды уровня ROOT помечены и требуют su.
 */
object TweakCatalog {

    val all: List<Tweak> = listOf(

        // ───────────────────────── CORE ─────────────────────────
        Tweak(
            id = "fixed_perf_mode",
            title = "Фиксированный режим производительности",
            description = "Держит CPU/GPU на максимальных частотах, отключает агрессивный сброс частот. " +
                "Главный рычаг для FPS-стабильности в играх.",
            category = TweakCategory.CORE,
            tier = TweakTier.SHIZUKU,
            apply = "cmd power set-fixed-performance-mode-enabled true",
            revert = "cmd power set-fixed-performance-mode-enabled false",
            warning = "Сильно греет и ест батарею — держи включённым только на время игры."
        ),
        Tweak(
            id = "disable_background_anims",
            title = "Отключить анимации интерфейса",
            description = "Скорости анимаций 0.5x — система реагирует заметно быстрее, " +
                "освобождается немного CPU на UI-потоках.",
            category = TweakCategory.DISPLAY,
            tier = TweakTier.SHIZUKU,
            apply = "settings put global window_animation_scale 0.5; " +
                "settings put global transition_animation_scale 0.5; " +
                "settings put global animator_duration_scale 0.5",
            revert = "settings put global window_animation_scale 1.0; " +
                "settings put global transition_animation_scale 1.0; " +
                "settings put global animator_duration_scale 1.0",
            backupKey = "global:window_animation_scale"
        ),
        Tweak(
            id = "imei_profiling_off",
            title = "Отключить профилировку/телеметрию",
            description = "Выключает часть фоновых сборщиков статистики и трейсинга, " +
                "которые периодически нагружают CPU.",
            category = TweakCategory.CORE,
            tier = TweakTier.SHIZUKU,
            apply = "device_config put runtime_native_boot disable_apk_verity_check true; " +
                "settings put global debug_view_attributes 0",
            revert = "settings put global debug_view_attributes 1",
            experimental = true
        ),

        // ──────────────────────── THERMAL ────────────────────────
        Tweak(
            id = "thermal_override",
            title = "Снять троттлинг (override-status 0)",
            description = "Thermal API: status 0 = «нет троттлинга». Убирает раннее снижение частот " +
                "под нагрузкой. Возврат — полный reset Thermal API.",
            category = TweakCategory.THERMAL,
            tier = TweakTier.SHIZUKU,
            apply = "cmd thermalservice override-status 0",
            revert = "cmd thermalservice reset",
            warning = "Телефон будет греться сильнее штатного. Корпус может стать горячим."
        ),
        Tweak(
            id = "thermal_light",
            title = "Мягкий режим (только светлый троттлинг)",
            description = "override-status 1 — допускает лишь лёгкое снижение частот. " +
                "Компромисс между температурой и производительностью.",
            category = TweakCategory.THERMAL,
            tier = TweakTier.SHIZUKU,
            apply = "cmd thermalservice override-status 1",
            revert = "cmd thermalservice reset"
        ),

        // ───────────────────────── GAME ─────────────────────────
        Tweak(
            id = "game_mode_perf",
            title = "Game Mode: performance для игры",
            description = "Переводит конкретную игру в режим максимальной производительности " +
                "через официальный Game Mode API.",
            category = TweakCategory.GAME,
            tier = TweakTier.SHIZUKU,
            apply = "cmd game mode performance {pkg}",
            revert = "cmd game mode standard {pkg}",
            needsPackage = true
        ),
        Tweak(
            id = "game_overlay_fps",
            title = "Game Overlay: 120 FPS-профиль",
            description = "Форсирует для игры mode=2 (performance) и fps=120 через device_config game_overlay. " +
                "Именно этот путь тюнеры зовут «анлоком 120 FPS».",
            category = TweakCategory.GAME,
            tier = TweakTier.SHIZUKU,
            apply = "device_config put game_overlay {pkg} mode=2,fps=120",
            revert = "device_config delete game_overlay {pkg}",
            needsPackage = true,
            experimental = true
        ),
        Tweak(
            id = "game_overlay_downscale",
            title = "Game Overlay: понижение внутреннего разрешения",
            description = "downscaleFactor снижает разрешение рендера → выше FPS в тяжёлых играх " +
                "ценой мягкости картинки.",
            category = TweakCategory.GAME,
            tier = TweakTier.SHIZUKU,
            apply = "device_config put game_overlay {pkg} mode=2,downscaleFactor=0.8",
            revert = "device_config delete game_overlay {pkg}",
            needsPackage = true,
            experimental = true
        ),
        Tweak(
            id = "game_dashboard",
            title = "Включить Game Dashboard",
            description = "Активирует игровую панель Pixel (оверлей FPS, запись, не беспокоить).",
            category = TweakCategory.GAME,
            tier = TweakTier.SHIZUKU,
            apply = "settings put secure game_dashboard_enabled 1",
            revert = "settings put secure game_dashboard_enabled 0",
            backupKey = "secure:game_dashboard_enabled"
        ),

        // ──────────────────────── DISPLAY ────────────────────────
        Tweak(
            id = "force_120",
            title = "Зафиксировать 120 Гц",
            description = "Принудительно 120 Гц вместо адаптивной SMOOTH DISPLAY — максимально плавный скролл " +
                "и стабильный кадр в 120-Гц играх.",
            category = TweakCategory.DISPLAY,
            tier = TweakTier.SHIZUKU,
            apply = "settings put system peak_refresh_rate 120.0; settings put system min_refresh_rate 120.0",
            revert = "settings put system min_refresh_rate 0.0",
            backupKey = "system:peak_refresh_rate",
            warning = "Расход батареи выше — адаптивная частота отключена."
        ),
        Tweak(
            id = "touch_response",
            title = "Повысить отзывчивость касаний",
            description = "Пометка чувствительности к тапу ввода — резче отклик в шутерах.",
            category = TweakCategory.DISPLAY,
            tier = TweakTier.SHIZUKU,
            apply = "settings put system touch_sounds_enabled 0",
            revert = "settings put system touch_sounds_enabled 1",
            experimental = true
        ),

        // ──────────────────────── RENDER ─────────────────────────
        Tweak(
            id = "angle_for_pkg",
            title = "ANGLE (OpenGL ES на Vulkan) для игры",
            description = "Заставляет игру использовать ANGLE-трансляцию GLES→Vulkan. " +
                "На части игр даёт стабильнее кадр. Официальный механизм Android.",
            category = TweakCategory.RENDER,
            tier = TweakTier.SHIZUKU,
            apply = "settings put global angle_gl_driver_selection_pkgs {pkg}; " +
                "settings put global angle_gl_driver_selection_values angle",
            revert = "settings delete global angle_gl_driver_selection_pkgs; " +
                "settings delete global angle_gl_driver_selection_values",
            needsPackage = true,
            warning = "Экспериментально: часть игр может рендериться неверно. Легко откатывается."
        ),
        Tweak(
            id = "disable_gpu_debug",
            title = "Убрать ограничитель GPU-отладки",
            description = "Снимает debug-флаги, которые могут включать validation-слой GPU-драйвера.",
            category = TweakCategory.RENDER,
            tier = TweakTier.SHIZUKU,
            apply = "settings put global gpu_debug_layers \"\"; settings put global gpu_debug_app \"\"",
            revert = "settings put global gpu_debug_app \"\"",
            experimental = true
        ),

        // ──────────────────────── MEMORY ─────────────────────────
        Tweak(
            id = "cached_procs",
            title = "Снизить лимит кэшированных процессов",
            description = "Меньше фоновых процессов → больше свободной RAM и CPU для активной игры.",
            category = TweakCategory.MEMORY,
            tier = TweakTier.SHIZUKU,
            apply = "settings put global activity_manager_constants max_cached_processes=32",
            revert = "settings delete global activity_manager_constants",
            experimental = true,
            warning = "Фоновые приложения будут чаще перезапускаться."
        ),

        // ──────────────────── KERNEL / ROOT ─────────────────────
        Tweak(
            id = "root_governor_perf",
            title = "Governor = performance (все ядра)",
            description = "Каждое ядро (X3/A715/A510) — governor performance, частота не падает вниз.",
            category = TweakCategory.KERNEL,
            tier = TweakTier.ROOT,
            apply = "for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do " +
                "echo performance > \$g 2>/dev/null; done",
            revert = "for g in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do " +
                "echo schedutil > \$g 2>/dev/null; done",
            warning = "Максимальный нагрев. После перезагрузки сбрасывается — в приложении есть авто-восстановление."
        ),
        Tweak(
            id = "root_min_freq_max",
            title = "Зафиксировать min = max частоту CPU",
            description = "Поднимает минимальную частоту до максимальной — исключает просадки кадра " +
                "при резких сценах.",
            category = TweakCategory.KERNEL,
            tier = TweakTier.ROOT,
            apply = "for c in /sys/devices/system/cpu/cpu*/cpufreq; do " +
                "cat \$c/scaling_max_freq > \$c/scaling_min_freq 2>/dev/null; done",
            revert = "for c in /sys/devices/system/cpu/cpu*/cpufreq; do " +
                "echo 300000 > \$c/scaling_min_freq 2>/dev/null; done",
            warning = "Только для root. Пути могут отличаться на кастомных ядрах — проверь результат в логе."
        ),
        Tweak(
            id = "root_zram",
            title = "Перенастроить ZRAM (сжатие памяти)",
            description = "Активирует ZRAM и меняет алгоритм сжатия на zstd — меньше подкачки в играх " +
                "с большим потреблением RAM.",
            category = TweakCategory.KERNEL,
            tier = TweakTier.ROOT,
            apply = "swapoff /dev/block/zram0 2>/dev/null; " +
                "echo 1 > /sys/block/zram0/reset 2>/dev/null; " +
                "echo zstd > /sys/block/zram0/comp_algorithm 2>/dev/null; " +
                "echo 4G > /sys/block/zram0/disksize 2>/dev/null; " +
                "mkswap /dev/block/zram0 2>/dev/null; swapon /dev/block/zram0 2>/dev/null",
            revert = "echo 1 > /sys/block/zram0/reset 2>/dev/null",
            warning = "Осторожно: неверный disksize может уронить систему. Проверь доступный zram перед запуском."
        ),
        Tweak(
            id = "root_io_sched",
            title = "I/O scheduler = none (UFS)",
            description = "Для NVMe/UFS планировщик none снижает задержки при загрузке текстур.",
            category = TweakCategory.KERNEL,
            tier = TweakTier.ROOT,
            apply = "for q in /sys/block/*/queue/scheduler; do echo none > \$q 2>/dev/null; done",
            revert = "for q in /sys/block/*/queue/scheduler; do echo mq-deadline > \$q 2>/dev/null; done",
            experimental = true
        ),
        Tweak(
            id = "root_gpu_governor",
            title = "GPU governor = performance (Mali-G715)",
            description = "Tensor G3 использует Mali-G715: держит devfreq GPU на максимальной " +
                "частоте вместо динамического снижения между кадрами. Дополняет CPU governor — " +
                "без этого твика проседания часто идут именно со стороны GPU, а не CPU.",
            category = TweakCategory.KERNEL,
            tier = TweakTier.ROOT,
            apply = "for g in /sys/class/devfreq/*mali*/governor /sys/class/devfreq/mali0/governor; do " +
                "echo performance > \$g 2>/dev/null; done",
            revert = "for g in /sys/class/devfreq/*mali*/governor /sys/class/devfreq/mali0/governor; do " +
                "echo simple_ondemand > \$g 2>/dev/null; done",
            warning = "Пути devfreq могут отличаться между сборками прошивки — проверь результат в логе.",
            experimental = true
        )
    )

    fun byCategory(): Map<TweakCategory, List<Tweak>> =
        all.groupBy { it.category }.toSortedMap(compareBy { it.ordinal })
}
