package com.pixeltuner.magictuner.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Neon = darkColorScheme(
    primary = Color(0xFF39FF14),        // кислотно-зелёный «tuner»
    onPrimary = Color(0xFF04140A),
    secondary = Color(0xFF00E5FF),
    onSecondary = Color(0xFF001014),
    background = Color(0xFF0B0F14),
    onBackground = Color(0xFFE6F2E9),
    surface = Color(0xFF141A22),
    onSurface = Color(0xFFE6F2E9),
    surfaceVariant = Color(0xFF1E2630),
    error = Color(0xFFFF5370)
)

@Composable
fun MagicTunerTheme(content: @Composable () -> Unit) {
    // Приложение задумано тёмным — «киберпанк-тюнер».
    @Suppress("UNUSED_EXPRESSION") isSystemInDarkTheme()
    MaterialTheme(colorScheme = Neon, content = content)
}
