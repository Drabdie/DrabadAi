# Optimizer (v0.2.0)

Android-приложение для отображения реальных показателей устройства и честного управления доступными режимами производительности.

**Что обновлено:**
- Свежие зависимости (Compose BOM 2024.12, Core, Lifecycle, Navigation)
- Добавлен GitHub Actions — можно собирать APK прямо с телефона через GitHub
- Версия поднята до 0.2.0

## Требования

- Android Studio / AndroidIDE / AIDE
- JDK 17 или новее
- Android SDK Platform 35
- Android SDK Build-Tools 35.x

Проект использует Android Gradle Plugin 8.5.2 и Gradle 8.7.

## Сборка на телефоне (AndroidIDE)

Смотри файл `ANDROIDIDE.txt` в корне.

## Сборка через GitHub Actions (самый удобный способ с Pixel)

1. Создай новый репозиторий на GitHub.
2. Залей **всё содержимое** папки Optimizer (чтобы settings.gradle.kts и build.gradle.kts были в корне репы).
3. Зайди в Actions → выбери "Build debug APK" → Run workflow.
4. После окончания скачай артефакт `optimizer-debug-apk`.

## Локальная сборка

### Linux / macOS

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

### Windows

```bat
gradlew.bat testDebugUnitTest
gradlew.bat assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## Проверка перед релизом

```bash
./gradlew clean testDebugUnitTest assembleDebug --stacktrace
```

Для release-сборки:

```bash
./gradlew clean testReleaseUnitTest assembleRelease --stacktrace
```

Release APK будет в `app/build/outputs/apk/release/`.

## Что проверено в проекте

- Android manifest и launcher icon присутствуют.
- Hilt/KSP, Room и Jetpack Compose подключены.
- Room хранит выбранный `PerformanceMode`.
- Системные показатели читаются через публичные Android API.
- Unit-тесты `CapabilityChecker` не требуют root.
- CI использует зафиксированный Gradle Wrapper вместо генерации wrapper на лету.

## Ограничения

Обычное Android-приложение не получает произвольный доступ к CPU governor, secure settings и системному управлению частотой обновления. Приложение не заявляет выполнение таких действий без соответствующих полномочий.
