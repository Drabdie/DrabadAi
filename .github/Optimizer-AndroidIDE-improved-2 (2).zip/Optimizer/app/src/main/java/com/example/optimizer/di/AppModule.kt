package com.example.optimizer.di

import android.content.Context
import androidx.room.Room
import com.example.optimizer.performance.PerformanceDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): PerformanceDatabase =
        Room.databaseBuilder(context, PerformanceDatabase::class.java, "optimizer.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun providePerformanceModeDao(db: PerformanceDatabase) = db.performanceModeDao()
}
