package com.example.optimizer.ui.dashboard

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.optimizer.data.DeviceSnapshot

@Composable
fun DashboardScreen(
    modifier: Modifier = Modifier,
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val data = viewModel.snapshot.collectAsState().value

    if (data == null) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else {
        LazyColumn(
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(buildCards(data)) { card -> InfoCard(card) }
        }
    }
}

private data class InfoCardData(val title: String, val value: String)

private fun buildCards(d: DeviceSnapshot): List<InfoCardData> = listOf(
    InfoCardData("Устройство", "${d.manufacturer} ${d.deviceModel}"),
    InfoCardData("Android", "${d.androidVersion} (API ${d.apiLevel})"),
    InfoCardData("CPU", "${d.cpuCoreCount} ядер, ${d.cpuAbi}"),
    InfoCardData(
        "RAM",
        if (d.ramTotalMb != null && d.ramAvailableMb != null)
            "${d.ramAvailableMb} / ${d.ramTotalMb} МБ свободно"
        else "Недоступно на этом устройстве"
    ),
    InfoCardData("Хранилище", "%.1f / %.1f ГБ свободно".format(d.storageFreeGb, d.storageTotalGb)),
    InfoCardData(
        "Батарея",
        buildString {
            append(d.batteryLevelPercent?.let { "$it%" } ?: "н/д")
            d.batteryTemperatureC?.let { append(", ${it}°C") }
            if (d.isCharging == true) append(", заряжается")
        }
    ),
    InfoCardData("Экран", "${d.screenResolution}, ${d.screenDensityDpi} dpi"),
    InfoCardData(
        "Частота обновления",
        d.screenRefreshRateHz?.let { "%.0f Гц".format(it) } ?: "Недоступно"
    ),
    InfoCardData("Термостатус", d.thermalStatus ?: "Недоступно на этом устройстве (нужен API 29+)")
)

@Composable
private fun InfoCard(card: InfoCardData) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(card.title, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            Text(card.value, style = MaterialTheme.typography.titleMedium)
        }
    }
}
