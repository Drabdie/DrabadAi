package com.example.optimizer.ui.modes

import android.content.ActivityNotFoundException
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.optimizer.performance.PerformanceMode

/**
 * Честный экран режимов: каждый режим объясняет, что реально делает,
 * а что недоступно без root/ADB, и не притворяется, что "ускорил" систему.
 */
@Composable
fun PerformanceModesScreen(
    modifier: Modifier = Modifier,
    viewModel: PerformanceModesViewModel = hiltViewModel()
) {
    val activeMode by viewModel.activeMode.collectAsState()
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(modeDefinitions) { def ->
            ModeCard(
                definition = def,
                isActive = def.mode == activeMode,
                onSelect = { viewModel.selectMode(def.mode) },
                onOpenSettings = { action ->
                    try {
                        context.startActivity(Intent(action))
                    } catch (e: ActivityNotFoundException) {
                        // На части устройств/прошивок такого экрана настроек нет —
                        // молча игнорировать нельзя, но и крашить приложение тоже.
                        // Ничего не делаем: кнопка просто не сработает на этом устройстве.
                    }
                }
            )
        }
    }
}

private data class ModeDefinition(
    val mode: PerformanceMode,
    val title: String,
    val description: String,
    val whatItChanges: String,
    val limitation: String,
    val settingsIntentAction: String?
)

private val modeDefinitions = listOf(
    ModeDefinition(
        mode = PerformanceMode.BALANCED,
        title = "Сбалансированный",
        description = "Настройки Android без изменений — баланс автономности и скорости.",
        whatItChanges = "Ничего не переключает — используются текущие системные настройки.",
        limitation = "Ограничений нет, это базовое состояние.",
        settingsIntentAction = null
    ),
    ModeDefinition(
        mode = PerformanceMode.PERFORMANCE,
        title = "Производительность",
        description = "Ориентир на максимальную отзывчивость интерфейса.",
        whatItChanges = "Открывает раздел \"Для разработчиков\", где можно вручную ускорить " +
            "системные анимации (Настройки анимации).",
        limitation = "Смена CPU governor недоступна без root — приложение не может " +
            "это сделать за тебя и не будет притворяться, что сделало.",
        settingsIntentAction = Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
    ),
    ModeDefinition(
        mode = PerformanceMode.GAMING,
        title = "Игровой",
        description = "Минимизация отвлекающих факторов во время игр.",
        whatItChanges = "Открывает настройки доступа к политике уведомлений — " +
            "оттуда можно включить \"Не беспокоить\" на время игры.",
        limitation = "Android не позволяет сторонним приложениям включать \"Не беспокоить\" " +
            "без явного разрешения пользователя.",
        settingsIntentAction = Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS
    ),
    ModeDefinition(
        mode = PerformanceMode.BATTERY_SAVER,
        title = "Экономия батареи",
        description = "Снижение энергопотребления.",
        whatItChanges = "Открывает системный экран энергосбережения.",
        limitation = "Программно включить Battery Saver стороннему приложению нельзя — " +
            "только через системный экран, который мы открываем.",
        settingsIntentAction = Settings.ACTION_BATTERY_SAVER_SETTINGS
    )
)

@Composable
private fun ModeCard(
    definition: ModeDefinition,
    isActive: Boolean,
    onSelect: () -> Unit,
    onOpenSettings: (String) -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    definition.title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )
                if (isActive) {
                    Text(
                        "✓ Активен",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(definition.description, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text("Что делает: ${definition.whatItChanges}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(4.dp))
            Text("Ограничение: ${definition.limitation}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onSelect, enabled = !isActive) {
                    Text(if (isActive) "Выбран" else "Выбрать")
                }
                definition.settingsIntentAction?.let { action ->
                    OutlinedButton(onClick = { onOpenSettings(action) }) {
                        Text("Открыть настройки")
                    }
                }
            }
        }
    }
}
