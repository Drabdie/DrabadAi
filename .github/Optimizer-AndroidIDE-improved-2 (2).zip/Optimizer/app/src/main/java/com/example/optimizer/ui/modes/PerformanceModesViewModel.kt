package com.example.optimizer.ui.modes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.optimizer.performance.PerformanceMode
import com.example.optimizer.performance.PerformanceModeDao
import com.example.optimizer.performance.PerformanceState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class PerformanceModesViewModel @Inject constructor(
    private val dao: PerformanceModeDao
) : ViewModel() {

    val activeMode: StateFlow<PerformanceMode> = dao.observeState()
        .map { it?.activeMode ?: PerformanceMode.BALANCED }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = PerformanceMode.BALANCED
        )

    fun selectMode(mode: PerformanceMode) {
        viewModelScope.launch {
            dao.setState(PerformanceState(activeMode = mode))
        }
    }
}
